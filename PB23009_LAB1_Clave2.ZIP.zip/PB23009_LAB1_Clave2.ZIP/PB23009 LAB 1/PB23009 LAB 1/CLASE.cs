﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PB23009_LAB_1
{
    class CLASE
    {
        public static double MostrarMenu(string categoria, string[] opciones, double[] precios)
        {
            Console.WriteLine($"\n{categoria}:");
            for (int i = 0; i < opciones.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {opciones[i]}: ${precios[i]}");
            }

            int eleccion;
            do
            {
                Console.Write($"Seleccione una opción de {categoria} (1-{opciones.Length}): ");
            }
            while (!int.TryParse(Console.ReadLine(), out eleccion) || eleccion < 1 || eleccion > opciones.Length);

            return precios[eleccion - 1];
        }
    }
}
