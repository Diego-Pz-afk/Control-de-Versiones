﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PB23009_LAB_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double PrecioFinal = 0;
            Console.WriteLine("BIENVENIDOS AL RESTAURANTE RETRO DE VIDEOJUEGOS");
            Console.WriteLine("Por favor, elija sus opciones del menú:");
            PrecioFinal += MostrarMenu("Platillos", new string[] { "Hamburguesa", "Pizza", "Ensalada" }, new double[] { 5, 7, 4 });
            PrecioFinal += MostrarMenu("Bebidas", new string[] { "Refresco", "Agua", "Cerveza" }, new double[] { 1, 0.5, 3 });
            PrecioFinal += MostrarMenu("Postres", new string[] { "Helado", "Pastel", "Galletas" }, new double[] { 2, 3, 1.5 });
            Console.WriteLine("¿Desea agregar un juego? (Pac-Man, Tetris, Ninguno)");
            string Videojuego = Console.ReadLine();
            if (Videojuego != "Ninguno")
            {
                PrecioFinal += 2;
            }
            Console.WriteLine($"Total a pagar: ${PrecioFinal}");
            Console.ReadKey();
        }

        public static double MostrarMenu(string categoria, string[] opciones, double[] precios)
        {
            Console.WriteLine($"\n{categoria}:");
            for (int i = 0; i < opciones.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {opciones[i]}: ${precios[i]}");
            }

            int eleccion;
            do
            {
                Console.Write($"Seleccione una opción de {categoria} (1-{opciones.Length}): ");
            }
            while (!int.TryParse(Console.ReadLine(), out eleccion) || eleccion < 1 || eleccion > opciones.Length);

            return precios[eleccion - 1];

        }
    }
}
